% DATE   : 2022-4-13
% AUTHOR : gaalokkong@stu.xidian.edu.cn
% SUBJECT: TD4_Filtrage

%%
close all;
clear all;
clc;

%% FILTRAGE SPATIAL -- FILTRES PASSE‐BAS SPATIAUX. SUPPRESSION DU BRUIT HF.

image_name = ["image_source\CARRE1.TIF"];
I = imread(image_name);
% figure("Name","IMAGE");
% imshow(image_name);

% image + noise gaussian
Ing = imnoise(I,"gaussian",0,0.05);
% image + noise pepper
Inp = imnoise(I,"salt & pepper",0.05);
f1 = figure("Name","IMAGE WITH NOISE AND FILTER");
set(f1, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(2,2,1)
imshow(Ing);    title(strcat("PSNR avec Gaussain Noise = ", string(psnr(Ing,I))));
subplot(2,2,2)
imshow(Inp);    title(strcat("PSNR avec S&P Noise = ", string(psnr(Inp,I))));

% filtage

Jg = medfilt2(Ing);
Jp = medfilt2(Inp);

subplot(2,2,3)
imshow(Jg);
title(strcat("PSNR avec filter median = ",string(psnr(Jg,I))));
subplot(2,2,4);
imshow(Jp);
title(strcat("PSNR avec filter median = ",string(psnr(Jp,I))));
print(f1,'image_result\IMAGE WITH NOISE AND FILTER','-dpng');

%% FILTRAGE SPATIAL -- FILTRE REHAUSSEUR DE CONTOURS.

k = input("k = ? (k>12)");
h =(1/(k-12))*[-1 -2 -1; -2 k -2; -1 -2 -1];

tmp = figure;
imshow(I);
disp("click to select a line");
[~,y] = ginput(1);
close(tmp);

y = round(y);
ligne1 = I(:,y);
J = filter2(h,I);
ligne2 = J(:,y);

f2 = figure("Name","FILTRE REHAUSSEUR DE CONTOURS");
set(f2, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(2,3,1)
imshow(I);  title("Image Original")
subplot(2,3,4)
imshow(mat2gray(J));  title("FILTRE REHAUSSEUR DE CONTOURS");
subplot(2,3,[2 3 5 6])
plot(ligne1);
hold on;
plot(ligne2);
legend("originale","afer");
title("Line");
print(f2,'image_result\FILTRE REHAUSSEUR DE CONTOURS','-dpng');

%% FILTRES FREQUENTIELS

load('Ie.mat');
Itd1 = Ie;
Itd1f = fftshift(fft2(Itd1));

H = filtrebutterworth([0.02 0.02],size(Itd1), 1);

Jf = Itd1f.*H;
J = abs(ifft2(Jf));
J = histeq(J);
J = imadjust(J,[],[0.1 0.7],1);

f3 = figure("Name",'FILTRES FREQUENTIELS');
set(f3, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(1,2,1)
imshow(Itd1);
title("Image Original");
subplot(1,2,2)
imshow(J);
title("FILTRES FREQUENTIELS")
print(f3,'image_result\FILTRES FREQUENTIELS','-dpng');

%% FILTRAGE NON‐LINEAIRE -- FILTRE MEDIAN

H = fspecial('gaussian');
J = imfilter(double(Ing),H);

f4 = figure("Name",'FILTRE MEDIAN');
set(f4, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(1,2,1)
imshow(Ing);
title(strcat("PSNR avec Image Gaussian Noise = ",string(psnr(uint8(Ing),I))));

subplot(1,2,2)
imshow(J);
title(strcat("PSNR avec filter median = ",string(psnr(uint8(J),I))));
print(f4,'image_result\FILTRE MEDIAN','-dpng');


%% FILTRAGE NON‐LINEAIRE -- TOP‐HAT ET BOTTOM‐HAT

image_name = ["image_source\cellules2b.jpg"];

[Ic,cmap] = imread(image_name);
Ic = rgb2gray(Ic);

sel = strel('disk',10,8);
Ict = imtophat(Ic,sel);
Icb = imbothat(Ic,sel);

f5 = figure("Name","TOP‐HAT ET BOTTOM‐HAT");
set(f5, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(3,1,1)
imshow(Ict); title('TOP-HAT');
subplot(3,1,2)
imshow(Icb); title('BOT-HAT');
subplot(3,1,3)
imshow(Ict-Icb); title('TOP-HAT - BOT-HAT');
print(f5,'image_result\TOP‐HAT ET BOTTOM‐HAT','-dpng');

