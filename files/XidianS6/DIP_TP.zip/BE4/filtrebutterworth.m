function H=filtrebutterworth(fc, taille, ordre)
H=zeros(taille);

k=-0.5 :1/taille(1):0.5-1/taille(1);
l=-0.5 :1/taille(2):0.5-1/taille(2);
[u,v]=meshgrid(k,l);
Denom=1.0+0.414*power(sqrt(u.*u+v.*v)./sqrt(fc(1)*fc(1)+fc(2)*fc(2)),2*ordre);
%size(Denom)
H=ones(taille);
H=H./(Denom);
end
