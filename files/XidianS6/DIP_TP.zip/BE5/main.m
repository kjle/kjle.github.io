% DATE   : 2022-4-18
% AUTHOR : gaalokkong@stu.xidian.edu.cn
% SUBJECT: TD5_Region

%%
close all;
clear all;
clc;

image_name = ["image_source\code.bmp","image_source\cellules2b.jpg"];

%% SEGMENTATION REGION -- EXTRAIRE UN OBJET
I = imread(image_name(1));
m = 4; n = 2;
f1 = figure('Name', 'EXTRAIRE UN OBJET');
set(f1, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(m,n,1);
imshow(I);  title(string(image_name(1)));
subplot(m,n,2);
imhist(I);  title(strcat(string(image_name(1))," histogram"));

J1 = imadjust(I,[67.97e-2 78.12e-2],[0 1],1);   % to make image observable
subplot(m,n,3);
imshow(J1); title(strcat(string(image_name(1))," après imadjust"));
subplot(m,n,4);
imhist(J1); title(strcat(string(image_name(1))," histogram après imadjust"));

J2 = imbinarize(J1,graythresh(I));
subplot(m,n,5);
imshow(J2); title(strcat(string(image_name(1))," après im2bw"));
subplot(m,n,6);
imhist(J2); title(strcat(string(image_name(1))," histogram après im2bw"));

se = strel('disk',10,8);
I = medfilt2(I,[6 6],'zeros');
J3 = imtophat(1-double(I),se);
J4 = imbothat(I,se);
subplot(m,n,7);
imshow(imbinarize(1-J3,graythresh(J3))); title(strcat(string(image_name(1))," après top-hat"));
subplot(m,n,8);
imshow(imbinarize(J4,graythresh(J4)*1.6)); title(strcat(string(image_name(1))," après bot-hat"));
print(f1,'image_result\EXTRAIRE UN OBJET','-dpng');

%% SEGMENTATION REGION -- GRANULOMETRIE
[Ic,cmap] = imread(image_name(2));
m = 4;  n = 4;
big = 9;   small = 3;           % big -- biggest nucleus, small -- smallest nucleus [unit:pixel]

Ic = rgb2gray(Ic);
sel0 = strel('disk',small,4);   % characteristic for the nucleus
sel = strel('disk',big,4);

Ic1 = imerode(Ic,sel);          % different operations for this image     
Ic2 = imdilate(Ic,sel);
Ic3 = imopen(Ic,sel);
Ic4 = imclose(Ic,sel);
Ic5 = imbothat(Ic,sel);
Ic6 = imtophat(Ic,sel);

f2 = figure('Name','GRANULOMETRIE');
set(f2, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(m,n,1); imshow(Ic1,cmap);   title('erosion');
subplot(m,n,5); imshow(Ic2,cmap);   title('dilatation');
subplot(m,n,9); imshow(Ic3,cmap);   title('ouverture');
subplot(m,n,13); imshow(Ic4,cmap);   title('fermeture');
subplot(m,n,6); imshow(Ic5,cmap);   title('bot-hat (large)');
subplot(m,n,2); imshow(Ic6,cmap);   title('top-hat');

Ic55 = imbothat(Ic,sel0);       
subplot(m,n,10); imshow(Ic55,cmap);  title('bot-hat (small)');
Ic50 = Ic5-Ic55;        % subtract nucleus from small nucleus, to emphasis the big nucleus
Ic50 = imbinarize(Ic50,graythresh(Ic50));
Ic50 = imopen(Ic50,strel('disk',2,8));                          % remove some of the smaller white image noise which smaller than 2 pixel
subplot(m,n,14); imshow(Ic50,cmap);  title('bot-hat (subtract)');

[L,num] = bwlabel(Ic50);      % connect components in the image and calculate the number of connected objects found in this image
subplot(m,n,[3 4]); imshow(L,cmap); title('image label');
rgb = label2rgb(L);           % make colors on the label (change BW image to RGB)
subplot(m,n,[7 8]); imshow(rgb); title('image label RGB');

subplot(m,n,[11 12 15 16]);   
imshow(Ic,[]);   hold on;     % show the original image and superpose the RGB nucleus
im = imshow(rgb);   set(im,'AlphaData',0.5);    % set the transparency of the RBG nucleus
title(strcat("total nucleus = ",string(num)));
print(f2,'image_result\GRANULOMETRIE','-dpng');
