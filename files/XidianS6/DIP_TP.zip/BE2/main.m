% DATE   : 2022-4-9
% AUTHOR : gaalokkong@stu.xidian.edu.cn
% SUBJECT: TD2_fft_shannon2019

%%
close all;
clear all;
clc;

%% ECHANTILLONNAGE ‐ EFFET DE MOIRE
% produce image originale
t = -192 : 191;
[x,y] = meshgrid(t,t);
d = sqrt(x.^2+y.^2);
f1 = 0.02;
f2 = 0.2;
I = 0.5+0.25*cos(2*pi*f1*d)+0.25*cos(2*pi*f2*d);
f1 = figure('Name','I'); 
set(f1, 'unit', 'normalized', 'position', [0,0,1,1]);
imshow(I)
print(f1,'image_result\I','-dpng');


% echantillonnage
fe = 1/4; 
Te = 1/fe;
Ie = I(1:Te:end,1:Te:end);
f2 = figure('Name','Ie');
set(f2, 'unit', 'normalized', 'position', [0,0,1,1]);
imshow(Ie,[]);
set(gcf,'color','none');
set(gca,'color','none');
print(f2,'image_result\Ie','-dpng');


%fft
If = fft2(I);
f3 = figure("Name",'FFT of I')
set(f3, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(1,2,1)
imshow(abs(If),[]);
title('no shift');
If = fftshift(If);
subplot(1,2,2)
imshow(abs(If),[]);
title('shift');
print(f3,'image_result\FFT of I','-dpng');


%visualize fft with ABS, surf-log, abs-log
If = fft2(Ie);
If = fftshift(If);
f4 = figure('Name','FFT of Ie');
set(f4, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(2,2,1);
imshow(abs(If),[]);
title('abs');
subplot(2,2,2)
surf(log(1+abs(If)));
title('surf-log');
subplot(2,2,[3 4])
imshow(log(1+abs(If)),[]);
title('log')
print(f4,'image_result\FFT of Ie','-dpng');

% inverse
f5 = figure('Name',"inverse of FFT with Fe = 1/4")
set(f5, 'unit', 'normalized', 'position', [0,0,1,1]);
Ifi = ifft2(If);
imshow(Ifi,[])
print(f5,'image_result\IFFT','-dpng');

%% FFT D’IMAGE REELLE

cd("image_source\");
image_name = ["cameraman.tif" "FEMME.tif" "COULOIR.tif"];
[m,n] = size(image_name);

for i=1:n
    I = imread(image_name(i));
    f6 = figure('Name',['I']);
    set(f6, 'unit', 'normalized', 'position', [0,0,1,1]);
    subplot(1,2,1)
    imshow(I)
    
    If=fftshift(fft2(I));
    subplot(1,2,2)
    imshow(log(1+abs(If)),[]);
    savepath = strcat('..\image_result\FFT_',image_name(i));
    print(f6,savepath,'-dpng');
end

%% ZERO PADDING

for i=1:n
    I = imread(image_name(i));
    f7 = figure('Name','I');
    set(f7, 'unit', 'normalized', 'position', [0,0,1,1]);
    subplot(2,2,1)
    imshow(I)
    
    If=fftshift(fft2(I));
    subplot(2,2,3)
    imshow(log(1+abs(If)),[]);

    Ifi = ifft2(If);
    subplot(2,2,2)
    imshow(Ifi,[]);
    title('ifft')
    
    Ifz = zeros(512*2,512*2);
    Ifz(1:256,1:256) = If;

    Ifzi = ifft2(Ifz);
    subplot(2,2,4)
    imshow(Ifzi,[]);
    title('ifft with zero padding')

    savepath = strcat('..\image_result\ZP_',image_name(i));
    print(f7,savepath,'-dpng');

end

cd("..");

