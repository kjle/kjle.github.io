% DATE   : 2022-4-6
% AUTHOR : gaalokkong@stu.xidian.edu.cn
% SUBJECT: TD1_couleur_3D

%%
close all;
clear all;
clc;

imageName = ["image_source/sport23.jpg"];
I = imread(imageName);

f1 = figure('Name',[strcat(imageName," in RGB")]);
set(f1, 'unit', 'normalized', 'position', [0,0,1,1]);

subplot(1,2,1)
imshow(I);
subplot(1,2,2)
m = im2bw(I(:,:,1),0.5);
imshow(m);

print(f1,'image_result\image in RGB','-dpng');

%%

I2 = rgb2ycbcr(I);
f2 = figure('Name',[strcat(imageName," in YCbCr")]);
set(f2, 'unit', 'normalized', 'position', [0,0,1,1]);

subplot(1,3,1)
imshow(I2(:,:,1));
title('Y');
subplot(1,3,2)
imshow(I2(:,:,2));
title('Cb');
subplot(1,3,3)
imshow(I2(:,:,3));
title('Cr');

print(f2,'image_result\image in YCbCr','-dpng');


%%
f3 = figure("Name","Masque")
set(f3, 'unit', 'normalized', 'position', [0,0,1,1]);

masque = imbinarize(I2(:,:,3), graythresh(I2(:,:,3)));
imshow(masque);
print(f3,'image_result\Masque','-dpng');

%%
f4 = figure("Name","Multipliez")
set(f4, 'unit', 'normalized', 'position', [0,0,1,1]);

subplot(2,3,1)
Ir = I(:,:,1).*uint8(masque);
imshow(Ir);
title('R');
subplot(2,3,2)
Ig = I(:,:,2).*uint8(masque);
imshow(Ig);
title('G');
subplot(2,3,3)
Ib= I(:,:,3).*uint8(masque);
imshow(Ib);
title('B');
subplot(2,3,[4 5 6])
J = I.*uint8(masque);
imshow(J);
title('color')

print(f4,'image_result\Multipliez','-dpng');


%%
K = rgb2gray(I);
masque2 = imbinarize(K, graythresh(K));
f5 = figure("Name","NON YCbCr")
set(f5, 'unit', 'normalized', 'position', [0,0,1,1]);

subplot(1,2,1)
imshow(masque2);
subplot(1,2,2)
imshow(I.*uint8(masque2));

print(f5,'image_result\NON YCbCr','-dpng');
