% DATE   : 2022-4-12
% AUTHOR : gaalokkong@stu.xidian.edu.cn
% SUBJECT: TD3_TrtNivPixel

%%
close all;
clear all;
clc;

cd("image_source");
image_name = ["CH0SRC.TIF","cameraman_degrade.tif","deg_classe3I5_L_1.jpg","deg_classe3I5_R_1.jpg"];

I = imread(image_name(1));
f1 = figure("Name",image_name(1));
set(f1, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(1,2,1)
imshow(I);
title('I');
subplot(1,2,2);
imhist(I);
title('HI');
savepath = strcat('..\image_result\orignal_',image_name(1));
print(f1,savepath,'-dpng');

for i =0.1:0.2:2
    %figure("Name","adjustment of I");
    f2 = figure;
    set(f2, 'unit', 'normalized', 'position', [0,0,1,1]);
    J=imadjust(I);
    subplot(1,3,1)
    imshow(J);
    title('ajustement automatique');
    J=imadjust(J,[],[],i);
    subplot(1,3,2)
    imshow(J);
    title(strcat("gamma ",string(i)));
    subplot(1,3,3)
    imhist(J);
    title(strcat("gamma ",string(i)));
    savepath = strcat('..\image_result\aplha_',string(i),'_',image_name(1));
    print(f2,savepath,'-dpng');
end

%% HISTOGRAMME
J=histeq(I);
f3 = figure("Name","egalisation")
set(f3, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(1,2,1)
imshow(J);
title('egalisation');
subplot(1,2,2)
imhist(J);
title('histogramme apres egalisation');
savepath = strcat('..\image_result\egalisation_',image_name(1));
print(f3,savepath,'-dpng');

for i = 1:8
    K=histeq(J,2^i);
    f4 = figure("Name",strcat("egalisation sur ", string(2^i)," niveaux"))
    set(f4, 'unit', 'normalized', 'position', [0,0,1,1]);
    subplot(1,2,1);
    imshow(K);
    subplot(1,2,2);
    imhist(K);
    savepath = strcat('..\image_result\egalisation sur_',string(2^i),'_',image_name(1));
    print(f4,savepath,'-dpng');
end

%%
A = imread(image_name(2));
f5 = figure("Name",image_name(2));
set(f5, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(1,2,1);
imshow(A);
subplot(1,2,2);
imhist(A);
savepath = strcat('..\image_result\',image_name(2));
print(f5,savepath,'-dpng');

f6 = figure("Name",'histeq');
set(f6, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(1,2,1);
imshow(histeq(A));
title('egalisation');
subplot(1,2,2)
imhist(histeq(A));
B = imread('cameraman.tif'); 
savepath = strcat('..\image_result\histeq_',image_name(2));
print(f6,savepath,'-dpng');

f7 = figure("Name","reff");
set(f7, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(1,2,1);
imshow(B);title('reference');
subplot(1,2,2);
imhist(B);
savepath = strcat('..\image_result\reff_',image_name(2));
print(f7,savepath,'-dpng');

Bh = imhist(B);
f8 = figure("Name","from degrade to ref")
set(f8, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(2,2,1)
imshow(A);
subplot(2,2,2)
imhist(A);
C = histeq(A,Bh);
subplot(2,2,3)
imshow(C);
subplot(2,2,4)
imhist(C);
savepath = strcat('..\image_result\from degrade to ref_',image_name(2));
print(f8,savepath,'-dpng');

%%
Il = imread(image_name(3));
Ir = imread(image_name(4));
f9 = figure('Name','Color picture')
set(f9, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(1,2,1)
imshow(Il);title('Left');
subplot(1,2,2)
imshow(Ir);title('Right');

Il2 = rgb2hsv(Il);
Ir2 = rgb2hsv(Ir);

% Il2 = histeq(Il2);
% H = imadjust(Il2(:,:,1),[],[],1.2);
% S = imadjust(Il2(:,:,2),[],[],1.2);
% V = imadjust(Il2(:,:,3),[],[],1.2);
% Il2(:,:,1) = H;
% Il2(:,:,2) = S;
% Il2(:,:,3) = V;
print(f9,'..\image_result\Color picture','-dpng');

f10 = figure("Name","histeq")
set(f10, 'unit', 'normalized', 'position', [0,0,1,1]);
% imshow(hsv2rgb(Il2));
subplot(2,1,1)
imhist(Il2);
subplot(2,1,2)
imhist(Ir2);
print(f10,'..\image_result\histeq_Color picture','-dpng');

Il3 = histeq(Il,imhist(Ir));
f11 = figure;
set(f11, 'unit', 'normalized', 'position', [0,0,1,1]);
subplot(2,1,1)
imhist(Il);
subplot(2,1,2)
imshow(Il);

cd("..");

