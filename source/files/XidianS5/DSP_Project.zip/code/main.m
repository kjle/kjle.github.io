% ***********************************************************
% Course: Signaux et Systemes - Filtrage Numerique
% Date: 25 Nov 2021
% Author: gaalokkong@stu.xidian.edu.cn
% ***********************************************************

% ********************** UPDATE NOTICE **********************
% 8 DEC 2021:
%   - add SmoothingFiler before the filtrage.
%   - add a new filer spectrumSub after FIR/IIR.
%   - change the figure(6).
% ***********************************************************


close all
clear all
clc
%% LOAD SIGNAL
load('sig2b.mat');
figure('Name','Original Signal');
signalProp(xb2b,Fs);

sound(xb2b, Fs);
pause(3);
%%
xb2b = movmean(xb2b,5);

%% FILTER PARAMETER
Fc = [1000 2000];                                               % Cutoff frequency
rp = 1;                                                         % Passband ripple in dB
rs = 80;                                                        % Stopband ripple in dB
a = [1 0];                                                      % Desired amplitudes
dev = [(10^(rp/20)-1)/(10^(rp/20)+1) 10^(-rs/20)];              % Convert the deviations to linear units

%% FIR FILTER DESIGN
% Version I: Parks-McClellan Order of Lowpass Filter
% [n,fo,ao,w] = firpmord(Fc,a,dev,Fs);                            % Design FIR filter with firpmord
% b = firpm(n,fo,ao,w);                                           % Coefficent

% Version II: Kaiser Window Bandpass Filter Design
[n, Wn, beta, ftype] = kaiserord(Fc,a,dev,Fs);                  % Design FIR filter with kaiserord
b = fir1(n,Wn,ftype,kaiser(n+1, beta), 'noscale');              % Coefficent
figure('Name','FIR Filter');
filterProp(b,1,n,1024,Fs);                                      % Visualize Properties of the Filter

x1 = filter(b,1,xb2b);                                          % Use FIR Filter to do the filtage

figure('Name','After FIR Filter');
signalProp(x1,Fs);
sound(x1, Fs);
pause(3);

%% IIR FILTER DESIGN
[n, Wn] = ellipord(Fc(1)/(Fs/2), Fc(2)/(Fs/2), rp, rs);
[b, a] = ellip(n, rp, rs, Wn);
figure('Name','IIR Filter')
filterProp(b,a,n,1024,Fs);                                      % Visualize Properties of the Filter

x2 = filter(b,a,xb2b);

figure('Name','After IIR Filter');
signalProp(x2,Fs);
sound(x2,Fs);
pause(3);

%% SpectrumSub
x11 = spectrumSub(x1,Fs);
x21 = spectrumSub(x2,Fs);
sound(x11, Fs); 
pause(2);
sound(x21, Fs);

%% COMPARE
figure('Name','Compare the 5 signals')
subplot(4,1,1)
plot(xb2b);
subplot(4,1,2)
plot(x1);
hold on
plot(x2);
legend('FIR','IIR');
subplot(4,1,3)
plot(x1);
hold on
plot(x11);
legend('FIR','FIR+spectrumSub');
subplot(4,1,4)
plot(x2);
hold on
plot(x21);
legend('IIR','IIR+spectrumSub');

