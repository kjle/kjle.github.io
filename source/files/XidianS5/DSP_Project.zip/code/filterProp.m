function filterProp(b,a,n,pointNum,Fs)
    [h,w] = freqz(b,a,pointNum,Fs);                                     % Frequency response
    hf = abs(h);                                                        % Magnitude on dB
    hphi = unwrap(angle(h));                                            % Phase on degree
    % Bode plot
    subplot(3,1,1)
    plot(w, 20*log10(hf));
    xlabel('frequency(Hz)');
    ylabel('Magnitude(dB)');
    subplot(3,1,2)
    plot(w, hphi);
    xlabel('frequency(Hz)');
    ylabel('Phase(degree)');
    % group delay
    subplot(3,1,3)
    grpdelay(b,a,n,Fs);
    xlabel('frequency(Hz)');
    ylabel('time(1/Fs)')
end
