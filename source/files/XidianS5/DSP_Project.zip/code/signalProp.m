function signalProp(signal,Fs)
    subplot(2,1,1)
    pwelch(signal,[],[],[],Fs);
    xlabel('frequency(kHz)');
    ylabel('|Amplitude of Power|');
    title('Power Spectral');
    subplot(2,1,2)
    [freq, P1] = myfft(signal,Fs);
    plot(freq,P1);
    grid on;
    xlabel('frequency (Hz)')
    ylabel('|Amplitude|')
    title('Single-Sided Amplitude Spectrum');
end
